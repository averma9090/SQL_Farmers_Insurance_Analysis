use ndap;


-- ----------------------------------------------------------------------------------------------
-- SECTION 1. 
-- SELECT Queries [5 Marks]

-- 	Q1.	Retrieve the names of all states (srcStateName) from the dataset.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
-- <write your answers in the empty spaces given, the length of solution queries (and the solution writing space) can vary>
select distinct srcStateName
from farmersinsurancedata;

###

-- 	Q2.	Retrieve the total number of farmers covered (TotalFarmersCovered) 
-- 		and the sum insured (SumInsured) for each state (srcStateName), ordered by TotalFarmersCovered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select sum(TotalFarmersCovered) as Total_Farmers_Covered, srcStateName as State_Name, round(sum(SumInsured)) as Sum_Insured
from farmersinsurancedata
group by State_Name
order by Total_Farmers_Covered desc;

-- ###

-- --------------------------------------------------------------------------------------
-- SECTION 2. 
-- Filtering Data (WHERE) [15 Marks]

-- 	Q3.	Retrieve all records where Year is '2020'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select *
from farmersinsurancedata
where srcYear = 2020;

-- ###

-- 	Q4.	Retrieve all rows where the TotalPopulationRural is greater than 1 million and the srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select *
from farmersinsurancedata
where TotalPopulationRural > 1000000 and srcStateName like '%HIMACHAL PRADESH%';

-- ###

-- 	Q5.	Retrieve the srcStateName, srcDistrictName, and the sum of FarmersPremiumAmount for each district in the year 2018, 
-- 		and display the results ordered by FarmersPremiumAmount in ascending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, srcDistrictName as District_Name, round(sum(FarmersPremiumAmount),2) as Farmers_Premium_Amount
from farmersinsurancedata
where srcYear = 2018
group by District_Name, State_Name
order by Farmers_Premium_Amount desc;

-- ###

-- 	Q6.	Retrieve the total number of farmers covered (TotalFarmersCovered) and the sum of premiums (GrossPremiumAmountToBePaid) for each state (srcStateName) 
-- 		where the insured land area (InsuredLandArea) is greater than 5.0 and the Year is 2018.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select sum(TotalFarmersCovered) as Total_Farmers_Covered, round(Sum(GrossPremiumAmountToBePaid),2) as Gross_Premium_Amount_to_be_Paid, srcStateName as State_Name
from farmersinsurancedata
where srcYear = 2018 and InsuredLandArea > 5.0
group by State_Name;

	  
-- ###
-- ------------------------------------------------------------------------------------------------

-- SECTION 3.
-- Aggregation (GROUP BY) [10 marks]

-- 	Q7. 	Calculate the average insured land area (InsuredLandArea) for each year (srcYear).
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select round(avg(InsuredLandArea),2) as Average_Insured_Land_Area, srcYear as Year
from farmersinsurancedata
group by Year;


-- ###

-- 	Q8. 	Calculate the total number of farmers covered (TotalFarmersCovered) for each district (srcDistrictName) where Insurance units is greater than 0.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcdistrictname, sum(totalfarmerscovered) as total_farmers_covered
from farmersinsurancedata
where insuranceunits > 0
group by srcdistrictname
order by total_farmers_covered desc;


-- ###

-- 	Q9.	For each state (srcStateName), calculate the total premium amounts (FarmersPremiumAmount, StatePremiumAmount, GOVPremiumAmount) 
-- 		and the total number of farmers covered (TotalFarmersCovered). Only include records where the sum insured (SumInsured) is greater than 500,000 (remember to check for scaling).
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, round((FarmersPremiumAmount + StatePremiumAmount + GOVPremiumAmount)*100000,2) as Total_Premium, TotalFarmersCovered, round(SumInsured* 100000,2) as Sum_Insured
from farmersinsurancedata
where SumInsured*100000 > 500000;



-- ###

-- -------------------------------------------------------------------------------------------------
-- SECTION 4.
-- Sorting Data (ORDER BY) [10 Marks]

-- 	Q10.	Retrieve the top 5 districts (srcDistrictName) with the highest TotalPopulation in the year 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName as District_Name, TotalPopulation
from farmersinsurancedata
where srcYear = 2020
order by TotalPopulation desc
limit 5;



-- ###

-- 	Q11.	Retrieve the srcStateName, srcDistrictName, and SumInsured for the 10 districts with the lowest non-zero FarmersPremiumAmount, 
-- 		ordered by insured sum and then the FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, srcDistrictName as District_Name, round(sum(SumInsured),5) as Sum_Insured, round(sum(FarmersPremiumAmount),5) as Farmers_Premium_Amount
from farmersinsurancedata
where FarmersPremiumAmount is not null and FarmersPremiumAmount > 0
group by srcDistrictName, srcStateName
order by  Sum_Insured asc, Farmers_Premium_Amount asc
limit 10;


###

-- 	Q12. 	Retrieve the top 3 states (srcStateName) along with the year (srcYear) where the ratio of insured farmers (TotalFarmersCovered) to the total population (TotalPopulation) is highest. 
-- 		Sort the results by the ratio in descending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, srcYear as Year, sum(TotalFarmersCovered)/sum(TotalPopulation) as Ratio_of_Insured_farmers
from farmersinsurancedata
group by srcStateName, srcYear
order by Ratio_of_Insured_farmers desc
limit 3;


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 5.
-- String Functions [6 Marks]

-- 	Q13. 	Create StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select LEFT(srcStateName, 3) as StateShortName
from farmersinsurancedata;


-- ###

-- 	Q14. 	Retrieve the srcDistrictName where the district name starts with 'B'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcDistrictName
from farmersinsurancedata
where srcDistrictName REGEXP '^[B]';


-- ###

-- 	Q15. 	Retrieve the srcStateName and srcDistrictName where the district name contains the word 'pur' at the end.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, srcDistrictName as District_Name
from farmersinsurancedata
where srcDistrictName REGEXP 'pur$';

-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 6.
-- Joins [14 Marks]

-- 	Q16. 	Perform an INNER JOIN between the srcStateName and srcDistrictName columns to retrieve the aggregated FarmersPremiumAmount for districts where the district’s Insurance units for an individual year are greater than 10.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName, srcDistrictName, srcYear, sum(FarmersPremiumAmount) as Total_Farmers_Premium_Amount -- sum(InsuranceUnits) as Total_Insurance_Units
from farmersinsurancedata
where InsuranceUnits > 10
group by srcDistrictName, srcStateName, srcYear;


-- ###

-- 	Q17.	Write a query that retrieves srcStateName, srcDistrictName, Year, TotalPopulation for each district and the the highest recorded FarmersPremiumAmount for that district over all available years
-- 		Return only those districts where the highest FarmersPremiumAmount exceeds 20 crores.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
with highest_farmer_premium as (
select srcStateName, srcDistrictName, srcYear, sum(TotalPopulation) as Total_Population, max(FarmersPremiumAmount*100000) as Max_Recorded_Farmer_Premium
from farmersinsurancedata
group by srcDistrictName, srcStateName, srcYear
order by Max_Recorded_Farmer_Premium desc
) select *
from highest_farmer_premium
where Max_Recorded_Farmer_Premium > 200000000;


-- ###

-- 	Q18.	Perform a LEFT JOIN to combine the total population statistics with the farmers’ data (TotalFarmersCovered, SumInsured) for each district and state. 
-- 		Return the total premium amount (FarmersPremiumAmount) and the average population count for each district aggregated over the years, where the total FarmersPremiumAmount is greater than 100 crores.
-- 		Sort the results by total farmers' premium amount, highest first.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
with population_stats as (
select srcStateName, srcDistrictName, srcYear, TotalPopulation
from farmersinsurancedata
),
farmers_stats as (select srcStateName, srcDistrictName, srcYear, TotalFarmersCovered, SumInsured, FarmersPremiumamount
from farmersinsurancedata
)
select p.srcStateName, p.srcDistrictName, sum(f.FarmersPremiumamount) as TotalFarmersPremium, avg(p.TotalPopulation) as Avg_Population
from population_stats p
left join
farmers_stats f
on p.srcStateName = f.srcStateName
and p.srcDistrictName = f.srcDistrictName
and p.srcYear = f.srcYear
group by p.srcStateName, p.srcDistrictName
having TotalFarmersPremium > 10000   -- Dividing by 10000 as the numbers are scaled down by dividing by 100000 in the table
order by TotalFarmersPremium desc;



-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 7.
-- Subqueries [10 Marks]

-- 	Q19.	Write a query to find the districts (srcDistrictName) where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName as State_Name, srcDistrictName as District_Name, sum(TotalFarmersCovered) as Sum_Total_FarmersCovered
from farmersinsurancedata
where TotalFarmersCovered > (
select avg(TotalFarmersCovered) -- 26896.7979
from farmersinsurancedata)
group by srcStateName, srcDistrictName;




-- ###

-- 	Q20.	Write a query to find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcStateName
from farmersinsurancedata
where SumInsured > (
select SumInsured
from farmersinsurancedata
order by FarmersPremiumAmount desc
limit 1);  -- There are no states like this because SumInsured and FarmersPremiumAmunt follow the same order. 




-- ###

-- 	Q21.	Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcdistrictname, srcstatename, farmerspremiumamount
from farmersinsurancedata
where srcstatename = (
        select srcstatename
        from farmersinsurancedata
        group by srcstatename
        order by sum(totalpopulation) desc
        limit 1
)
and 
farmerspremiumamount > (
        select avg(farmerspremiumamount)
        from farmersinsurancedata
        where srcstatename = (
            select srcstatename
            from farmersinsurancedata
            group by srcstatename
            order by sum(totalpopulation) desc
            limit 1
	)
);



-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 8.
-- Advanced SQL Functions (Window Functions) [10 Marks]

-- 	Q22.	Use the ROW_NUMBER() function to assign a row number to each record in the dataset ordered by total farmers covered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select 
    srcstatename,
    srcdistrictname,
    totalfarmerscovered,
    row_number() over (order by totalfarmerscovered desc) as row_num
from farmersinsurancedata;



-- ###

-- 	Q23.	Use the RANK() function to rank the districts (srcDistrictName) based on the SumInsured (descending) and partition by alphabetical srcStateName.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcstatename, srcdistrictname, suminsured,
rank() over (
        partition by srcstatename 
        order by suminsured desc
    ) as district_rank
from farmersinsurancedata
order by srcstatename asc, district_rank asc;



-- ###

-- 	Q24.	Use the SUM() window function to calculate a cumulative sum of FarmersPremiumAmount for each district (srcDistrictName), ordered ascending by the srcYear, partitioned by srcStateName.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
select srcstatename, srcdistrictname,srcyear, farmerspremiumamount,
    sum(farmerspremiumamount) over (
        partition by srcstatename, srcdistrictname 
        order by srcyear asc
    ) as cumulative_premium
from farmersinsurancedata
order by srcstatename, srcdistrictname, srcyear;



-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 9.
-- Data Integrity (Constraints, Foreign Keys) [4 Marks]

-- 	Q25.	Create a table 'districts' with DistrictCode as the primary key and columns for DistrictName and StateCode. 
-- 		Create another table 'states' with StateCode as primary key and column for StateName.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

create table states (
    statecode varchar(10) primary key,
    statename varchar(100)
);

create table districts (
    districtcode varchar(10) primary key,
    districtname varchar(100),
    statecode varchar(10),
    foreign key (statecode) references states(statecode)
);


-- ###

-- 	Q26.	Add a foreign key constraint to the districts table that references the StateCode column from a states table.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >

-- Done in previous question


-- ###

-- -------------------------------------------------------------------------------------------------

-- SECTION 10.
-- UPDATE and DELETE [6 Marks]

-- 	Q27.	Update the FarmersPremiumAmount to 500.0 for the record where rowID is 1.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
update farmersinsurancedata
set farmerspremiumamount = 500.0
where rowid = 1;



-- ###

-- 	Q28.	Update the Year to '2021' for all records where srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
update farmersinsurancedata
set srcyear = '2021'
where srcStatename = 'HIMACHAL PRADESH';


-- ###

-- 	Q29.	Delete all records where the TotalFarmersCovered is less than 10000 and Year is 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
delete from farmersinsurancedata
where totalfarmerscovered < 10000 and srcyear = 2020;


-- ###